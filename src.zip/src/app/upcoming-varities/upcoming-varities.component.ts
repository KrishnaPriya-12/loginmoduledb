import { Component } from '@angular/core';

@Component({
  selector: 'app-upcoming-varities',
  templateUrl: './upcoming-varities.component.html',
  styleUrls: ['./upcoming-varities.component.css']
})
export class UpcomingVaritiesComponent {

}
