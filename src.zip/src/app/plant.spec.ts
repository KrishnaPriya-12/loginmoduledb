import { Plant } from './plant';

describe('Plant', () => {
  it('should create an instance', () => {
    expect(new Plant()).toBeTruthy();
  });
});
